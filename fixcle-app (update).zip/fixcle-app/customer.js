import React from 'react';
import {StyleSheet, Text, View, Image, TextInput, TouchableOpacity} from 'react-native';
import {globalsty} from './globalSty'
import {useState} from 'react';

export default function Customer ({navigation}) {

const mobil=()=>{
  navigation.navigate("Mobil")
}

const motor=()=>{
  navigation.navigate("Motor")
}

return(

  <View style={globalsty.containerCust}>

  <Image style={globalsty.imageSty2} source={require('./Image/LogoFixcle.png')}/>

  <Text style={globalsty.choose}>Choose Vehicle</Text>

  <View style={globalsty.custView}>
    <TouchableOpacity style={globalsty.buttonVehic} onPress={mobil}>  
      <Image style={globalsty.imgVehicle} source={require('./Icon/car.png')} />

    </TouchableOpacity>

    <TouchableOpacity style={globalsty.buttonVehic} onPress={motor}>  
      <Image style={globalsty.imgVehicle} source={require('./Icon/mbike.png')} />

    </TouchableOpacity>
  </View>


  </View>
)
}