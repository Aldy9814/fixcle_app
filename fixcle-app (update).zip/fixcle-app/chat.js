import React from 'react';
import {StyleSheet, Text, View, Image, TextInput, TouchableOpacity} from 'react-native';
import {globalsty} from './globalSty'
import {useState} from 'react';

export default function Chat ({navigation}) {
  return (

    <View style={globalsty.containerDefault}> 
    
      <View style={globalsty.containerChat}>
        <Image style={globalsty.iconDisplay} source={require('./Icon/roundUser.png')} />

        <View style={globalsty.custDataV}> 
        <Text style={globalsty.custChatName}> Customer Name </Text>
        
        <Text style={globalsty.custData}></Text>
        <Text style={globalsty.custData}> .................................. </Text>
        
      </View>

      <Text> 12.30 </Text>
        

      </View>

      <View style={globalsty.containerChat}>
        <Image style={globalsty.iconDisplay} source={require('./Icon/roundUser.png')} />

        <View style={globalsty.custDataV}> 
        <Text style={globalsty.custChatName}> Customer Name </Text>
        
        <Text style={globalsty.custData}></Text>
        <Text style={globalsty.custData}> .................................. </Text>
        
      </View>

      <Text> 11.45 </Text>
        

      </View>

      <View style={globalsty.containerChat}>
        <Image style={globalsty.iconDisplay} source={require('./Icon/roundUser.png')} />

        <View style={globalsty.custDataV}> 
        <Text style={globalsty.custChatName}> Customer Name </Text>
        
        <Text style={globalsty.custData}></Text>
        <Text style={globalsty.custData}> .................................. </Text>
        
      </View>

      <Text> 10.20 </Text>
        

      </View>





    
    </View>


  )
}