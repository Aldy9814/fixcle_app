import React from 'react';
import {StyleSheet, Text, View, Image, TextInput, TouchableOpacity} from 'react-native';
import {globalsty} from './globalSty'
import {useState} from 'react';

export default function OwnerDetail ({navigation}) {

  const [mechanic, setMechanic] = useState('')

  const assign =(mechanic)=>{setMechanic(mechanic)}

  const goChat=()=>{
    navigation.navigate('Chat')
  }


return(

<View style={globalsty.containerDefault}>

  <View style={globalsty.containerTop}>
      <Image style={globalsty.iconSmall} source={require('./Image/LogoFixcle.png')}/>
      <Text style={globalsty.textTop}>FIXCLE</Text>
      <Image style={globalsty.iconSmall} source={require('./Icon/bell.png')} /> 
  </View>

  <View style={globalsty.containerDetail}>
  
    <View style={globalsty.containerImage}>
      <TouchableOpacity> 
        <Image style={globalsty.arrow} source={require('./Icon/arrowLeft.png')} />
      </TouchableOpacity>
        <Image source={require('./Image/image1.png')} />
      <TouchableOpacity>
        <Image style={globalsty.arrow} source={require('./Icon/arrowRight.png')}/>
      </TouchableOpacity>
    </View>

    <View style={globalsty.containerIssueDetail}>
      <Text> Issuse Detail </Text>
      <Text> ........................................................ </Text>

    </View>

  </View>

  <TextInput style={globalsty.inputSty} placeholder='assign mechanic'/>

  <View style={globalsty.containerMechanicList}>  

      <View style={globalsty.containerChat}>
        <Image style={globalsty.iconDisplay} source={require('./Icon/roundUser.png')} />

        <View style={globalsty.custDataV}> 
          <Text style={globalsty.custChatName}> Mechanic Name </Text>
        
          <Text style={globalsty.custData}></Text>
          <Text style={globalsty.custData}>  </Text>
        
        </View>

        <Text> assign </Text>
        

      </View>

      <View style={globalsty.containerChat}>
        <Image style={globalsty.iconDisplay} source={require('./Icon/roundUser.png')} />

        <View style={globalsty.custDataV}> 
          <Text style={globalsty.custChatName}> Mechanic Name </Text>
        
          <Text style={globalsty.custData}></Text>
          <Text style={globalsty.custData}>  </Text>
        
        </View>

        <Text> working.. </Text>
        

      </View>

      <View style={globalsty.containerChat}>
        <Image style={globalsty.iconDisplay} source={require('./Icon/roundUser.png')} />

        <View style={globalsty.custDataV}> 
          <Text style={globalsty.custChatName}> Mechanic Name </Text>
        
          <Text style={globalsty.custData}></Text>
          <Text style={globalsty.custData}>  </Text>
        
        </View>

        <Text> working.. </Text>
        

      </View>
    
  </View>

  

  <View style={globalsty.containerBottomDetailOwner}>
      <TouchableOpacity style={globalsty.buttonMenuBottom} onPress={goChat}>
      <Image style={globalsty.iconSmall} source={require('./Icon/messege.png')}/>
      <Text>  chat </Text>
      </TouchableOpacity>

      <TouchableOpacity style={globalsty.buttonMenuBottom} onPress={goChat}>
      <Image style={globalsty.iconSmall} source={require('./Icon/home.png')} />
      <Text>  home </Text>
      </TouchableOpacity>

      <TouchableOpacity style={globalsty.buttonMenuBottom} onPress={goChat}>
      <Image style={globalsty.iconSmall} source={require('./Icon/profile.png')} /> 
      <Text>   account </Text>
      </TouchableOpacity>
  </View>

</View>

)}