import React from 'react';
import {StyleSheet, Text, View, Image, TextInput, TouchableOpacity} from 'react-native';
import {globalsty} from './globalSty'
import {useState} from 'react';

export default function Signup ({navigation}) {

const [email, setemail] = useState("")
const [user, setuser] = useState("")
const [pass, setpass] = useState("")

const inputEmail =(email)=>{setemail(email)}
const inputUser =(user)=>{setuser(user)}
const inputPass =(pass)=>{setpass(pass)}

//const [userSave, setuserSave] = useState 

const [notif1, setnotif1] = useState("")
const [notif2, setNotif2] = useState("")

const signup=()=>{
if(email == ''){
  setnotif2('')
  setnotif1('Maaf data anda kurang lengkap!')
}
else if(user == ''){
  setnotif2('')
  setnotif1('Maaf data anda kurang lengkap!')
}
else if(pass == ''){
  setnotif2('')
  setnotif1('Maaf data anda kurang lengkap!')
}
else{
  setnotif1('')
  setNotif2('Selamat anda telah terdaftar!')
}
}

const login=()=>{
  navigation.navigate('Login')
}

return(

<View style={globalsty.containerLogin}>

<Image style={globalsty.imageSty2} source={require("./Image/LogoFixcle.png")}/>

<View style={globalsty.containerLogin2}>

<View style={globalsty.inputV}>
  <TextInput style={globalsty.inputSty} placeholder="username" onChangeText={inputUser} />
</View>

<View style={globalsty.inputV}>
  <TextInput style={globalsty.inputSty} placeholder="email" onChangeText={inputEmail} />
</View>

<View style={globalsty.inputV}>
  <TextInput style={globalsty.inputSty} placeholder="password" onChangeText={inputPass} />
</View>

<View style={globalsty.buttonLogin}>
  <TouchableOpacity style={globalsty.buttonStyLogin} onPress={signup}> Sign Up </TouchableOpacity>
</View>

<View>
  <Text style={globalsty.notifSty}> {notif1} </Text>
  <Text style={globalsty.notifSty2}> {notif2} </Text>
</View>

<View style={globalsty.goSignup}>
  <Text> Already have an account? </Text>

  <TouchableOpacity onPress={login}> Log In</TouchableOpacity>
</View>



</View>
</View>



)

}