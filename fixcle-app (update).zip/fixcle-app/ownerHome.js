import React from 'react';
import {StyleSheet, Text, View, Image, TextInput, TouchableOpacity} from 'react-native';
import {globalsty} from './globalSty'
import {useState} from 'react';

export default function OwnerHome ({navigation}) {

  const addMecha=()=>{
    navigation.navigate('AddMechanic')
  }

  const goDetail=()=>{
    navigation.navigate("OwnerDetail")
  }

  const goChat=()=>{
    navigation.navigate('Chat')
  }

return(

   <View style={globalsty.containerDefault}>

    <View style={globalsty.containerTop}>
      <Image style={globalsty.iconSmall} source={require('./Image/LogoFixcle.png')}/>
      <Text style={globalsty.textTop}>FIXCLE</Text>
      <Image style={globalsty.iconSmall} source={require('./Icon/bell.png')} /> 
    </View>

    <TouchableOpacity style={globalsty.buttonAdd} onPress={addMecha}> Add Mechanic </TouchableOpacity>

    <Text style={globalsty.titleOrder}> Order List </Text>

    <View style={globalsty.containerList}> 
      <Image style={globalsty.iconDisplay} source={require('./Icon/roundUser.png')} />

      <View style={globalsty.custDataV}> 
        <Text style={globalsty.custData}> Customer Name </Text>
        
        <Text style={globalsty.custData}> Vehicle </Text>
        <Text style={globalsty.custData}> Vehicle Type </Text>
        
      </View>

      <View>
        <TouchableOpacity style={globalsty.buttonDetail} onPress={goDetail}> Details >> 
        </TouchableOpacity>
      </View>

    </View>

    <View style={globalsty.containerList}> 
      <Image style={globalsty.iconDisplay} source={require('./Icon/roundUser.png')} />

      <View style={globalsty.custDataV}> 
        <Text style={globalsty.custData}> Customer Name </Text>
        
        <Text style={globalsty.custData}> Vehicle </Text>
        <Text style={globalsty.custData}> Vehicle Type </Text>
        
      </View>

      <View>
        <TouchableOpacity style={globalsty.buttonDetail} onPress={goDetail}> Details >> 
        </TouchableOpacity>
      </View>

    </View>

    <View style={globalsty.containerList}> 
      <Image style={globalsty.iconDisplay} source={require('./Icon/roundUser.png')} />

      <View style={globalsty.custDataV}> 
        <Text style={globalsty.custData}> Customer Name </Text>
        
        <Text style={globalsty.custData}> Vehicle </Text>
        <Text style={globalsty.custData}> Vehicle Type </Text>
        
      </View>

      <View>
        <TouchableOpacity style={globalsty.buttonDetail} onPress={goDetail}> Details >> 
        </TouchableOpacity>
      </View>

    </View>

    <View style={globalsty.containerBottomOwner}>
      <TouchableOpacity style={globalsty.buttonMenuBottom} onPress={goChat}>
      <Image style={globalsty.iconSmall} source={require('./Icon/messege.png')}/>
      <Text>  chat </Text>
      </TouchableOpacity>

      <TouchableOpacity style={globalsty.buttonMenuBottom} onPress={goChat}>
      <Image style={globalsty.iconSmall} source={require('./Icon/home.png')} />
      <Text>  home </Text> 
      </TouchableOpacity>

      <TouchableOpacity style={globalsty.buttonMenuBottom} onPress={goChat}>
      <Image style={globalsty.iconSmall} source={require('./Icon/profile.png')} /> 
      <Text>   account </Text>
      </TouchableOpacity>
    </View>

  </View>
)
}