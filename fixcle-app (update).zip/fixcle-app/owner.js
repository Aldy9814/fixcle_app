import React from 'react';
import {StyleSheet, Text, View, Image, TextInput, TouchableOpacity, Picker} from 'react-native';
import {globalsty} from './globalSty'
import {useState} from 'react';

export default function Owner ({navigation}) {

  const official=()=>{
  navigation.navigate("OwnerOfficial")
}

const nonoff=()=>{
  navigation.navigate("OwnerNon")
}


return(

  <View style={globalsty.containerCust}>

  <Image style={globalsty.imageSty2} source={require('./Image/LogoFixcle.png')}/>

  <Text style={globalsty.choose}> Register Your Workshop </Text>

  <View style={globalsty.custView}>
    <TouchableOpacity style={globalsty.buttonVehic} onPress={official}>  
      <Text style={globalsty.textForm}>OFFICIAL </Text>

    </TouchableOpacity>

    <TouchableOpacity style={globalsty.buttonVehic} onPress={nonoff}>  
      <Text style={globalsty.textForm}>NON-OFFICIAL </Text>

    </TouchableOpacity>
  </View>


  </View>
)
}