import React from 'react';
import {StyleSheet, Text, View, Image, TextInput, TouchableOpacity, Picker} from 'react-native';
import {globalsty} from './globalSty'
import {useState} from 'react';

export default function OwnerAccount ({navigation}) {
  return(
    <View style={globalsty.containerDefault}> 

    <View>
      
    </View>
    
    </View>
  )
}