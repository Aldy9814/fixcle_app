import React from 'react';
import {StyleSheet, Text, View, Image, TextInput, TouchableOpacity} from 'react-native';
import {globalsty} from '../globalSty'
import {useState} from 'react';

export default function MechanicDetail ({navigation}) {

  const goChat=()=>{
    navigation.navigate('Chat')
  }

  const gomap=()=>{
    navigation.navigate('MechanicMap')
  }

return(

<View style={globalsty.containerDefault}>

  <View style={globalsty.containerTop}>
      <Image style={globalsty.iconSmall} source={require('../Image/LogoFixcle.png')}/>
      <Text style={globalsty.textTop}>FIXCLE</Text>
      <Image style={globalsty.iconSmall} source={require('../Icon/bell.png')} /> 
  </View>

  <View style={globalsty.containerDetail}>
  
    <View style={globalsty.containerImage}>
      <TouchableOpacity> 
        <Image style={globalsty.arrow} source={require('../Icon/arrowLeft.png')} />
      </TouchableOpacity>
        <Image source={require('../Image/image1.png')} />
      <TouchableOpacity>
        <Image style={globalsty.arrow} source={require('../Icon/arrowRight.png')}/>
      </TouchableOpacity>
    </View>

    <View style={globalsty.containerIssueDetail}>
      <Text> Issuse Detail </Text>
      <Text> ........................................................ </Text>

    </View>

  </View>

  <TouchableOpacity style={globalsty.buttonAccept} onPress={gomap}> Accept </TouchableOpacity>

  <View style={globalsty.containerBottom}>
      <TouchableOpacity style={globalsty.buttonMenuBottom} onPress={goChat}>
      <Image style={globalsty.iconSmall} source={require('../Icon/messege.png')}/>
      <Text>  chat </Text>
      </TouchableOpacity>

      <TouchableOpacity style={globalsty.buttonMenuBottom} onPress={goChat}>
      <Image style={globalsty.iconSmall} source={require('../Icon/home.png')} />
      <Text>  home </Text> 
      </TouchableOpacity>

      <TouchableOpacity style={globalsty.buttonMenuBottom} onPress={goChat}>
      <Image style={globalsty.iconSmall} source={require('../Icon/profile.png')} /> 
      <Text>   account </Text>
      </TouchableOpacity>
  </View>

</View>

)}