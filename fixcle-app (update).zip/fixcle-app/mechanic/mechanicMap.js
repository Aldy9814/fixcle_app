import React from 'react';
import {StyleSheet, Text, View, Image, TextInput, TouchableOpacity} from 'react-native';
import {globalsty} from '../globalSty'
import {useState} from 'react';

export default function MechanicMap ({navigation}) {

const goChat=()=>{
    navigation.navigate('Chat')
  }

return(

<View style={globalsty.containerDefault}>

  <View style={globalsty.containerTop}>
    <Image style={globalsty.iconSmall} source={require('../Image/LogoFixcle.png')}/>
    <Text style={globalsty.textTop}>FIXCLE</Text>
    <Image style={globalsty.iconSmall} source={require('../Icon/bell.png')} /> 
  </View>

  <Image style={globalsty.imageMap} source={require('../Image/map.png')} />

  <View style={globalsty.mechanicOngoing}>
    <Image style={globalsty.iconDisplay} source={require('../Icon/roundUser.png')} />

    <View style={globalsty.custDataV}> 
      <Text style={globalsty.custData}> Customer Name </Text>
        
      <Text style={globalsty.custData}> Vehicle </Text>
      <Text style={globalsty.custData}> Vehicle Type </Text>
        
    </View>

    <Image style={globalsty.pin} source={require('../Icon/pin.png')} />
    
  </View>

  <View style={globalsty.containerVehicDetail}> 

    <View style={globalsty.containerVehic}>
      <Text> Vehicle Detail </Text>
    </View>

    <View style={globalsty.custDataV}> 
      
      <Text style={globalsty.custData}> Vehicle </Text>
      <Text style={globalsty.custData}> Vehicle Type </Text>
        
    </View>


  </View>

  <View style={globalsty.containerBottomMap}>
      <TouchableOpacity style={globalsty.buttonMenuBottom} onPress={goChat}>
      <Image style={globalsty.iconSmall} source={require('../Icon/messege.png')}/>
      <Text>  chat </Text>
      </TouchableOpacity>

      <TouchableOpacity style={globalsty.buttonMenuBottom} onPress={goChat}>
      <Image style={globalsty.iconSmall} source={require('../Icon/home.png')} />
      <Text>  home </Text> 
      </TouchableOpacity>

      <TouchableOpacity style={globalsty.buttonMenuBottom} onPress={goChat}>
      <Image style={globalsty.iconSmall} source={require('../Icon/profile.png')} /> 
      <Text>   account </Text>
      </TouchableOpacity>
  </View>


</View>

)

}