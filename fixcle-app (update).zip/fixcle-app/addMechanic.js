import React from 'react';
import {StyleSheet, Text, View, Image, TextInput, TouchableOpacity, Picker} from 'react-native';
import {globalsty} from './globalSty'
import {useState} from 'react';

export default function AddMechanic ({navigation}) {

  const [name, setName] = useState('')
  const [id, setId] = useState('')

  const [notif, setNotif] = useState('')
  const [notif2, setNotif2] = useState('')

  const [service, setService] = useState('')
  const [s, setS] = useState('')

  const [mecha, setMecha] = useState('')

  const save=()=>{  
    if( name == '' && id == '' && service == ''){
      setNotif('data anda belum lengkap!')
      setNotif2('')
    }
    else{
      setNotif('')
      setNotif2('data anda telah tersimpan!')
    }
  }
  
  return(
    <View style={globalsty.containerHome}> 

    <Text style={globalsty.textAddMech}>Add Your Mechanic </Text>
  

    <View style={globalsty.containerAddMecha}>
      <TextInput style={globalsty.inputAddMecha} placeholder='Mechanic 1' />

      <Text style={globalsty.textAddMechForm}>Name </Text>
      <TextInput style={globalsty.inputAddMecha2} placeholder='Mechanic Name' />


      <Text style={globalsty.textAddMechForm}>ID </Text>
      <TextInput style={globalsty.inputAddMecha2} placeholder='Mechanic ID' />

      <Text style={globalsty.textAddMechForm}>Service Capabilities </Text>
      <Picker 
      style={globalsty.addmechaDrop}
      selectedValue = {service}
      onValueChange={(s, itemIndex) => setService(s)}>
      <Picker.Item label = 'Choose Services' value = ''/>
      <Picker.Item label = 'Car' value = 'Car'/>
      <Picker.Item label = 'Motorcycle' value = 'Motorcycle'/>
      <Picker.Item label = 'Car & Motorcycle' value = 'CarMotorcycle'/>
      </Picker>

      <Text style={globalsty.notifSty}>{notif} </Text>
      <Text style={globalsty.notifSty2}>{notif2} </Text>
    
      <TouchableOpacity style={globalsty.buttonSave} onPress={save}>Save</TouchableOpacity>

      
    </View>
    
    </View>
  )
}