import {StyleSheet} from 'react-native';

export const globalsty = StyleSheet.create({

  containerDefault: {
    flex: 1,
    justifyContent: 'top',
    backgroundColor: '#CFE2E2',
    width: 330,
    height: 800,
    padding: 0,  
  },

  containerChat: {
    margin: 5,
    height: 60,
    flexDirection: 'row',
    
  },

  containerHome: {
    flex: 1,
    justifyContent: 'top',
    backgroundColor: 'black',
    width: 330,
    height: 800,
    padding: 8,
  },

  containerLogin: {
    flex: 1,
    justifyContent: 'top',
    backgroundColor: 'white',
    width: 330,
    height: 800,
    padding: 8,  
  },

  containerCust: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'white',
    width: 330,
    height: 800,
    padding: 8,
    shadowOpacity: 50,
    shadowOffset: 5,
    shadowRadius: 5, 
    shadowColor: "#91C9CB", 
  },

  containerForm: {
    flex: 1,
    justifyContent: 'Top',
    backgroundColor: 'black',
    width: 330,
    height: 1500,
    padding: 0,
    shadowOpacity: 50,
    shadowOffset: 5,
    shadowRadius: 5, 
    shadowColor: "#91C9CB", 
  },

  containerLogin2: {
    flex: 1,
    marginTop: 30,
    justifyContent: 'top',
    backgroundColor: '#c1e7dd',
    width: 320,
    height: 800,
    padding: 8,
    borderRadius: 10,
  },

  containerRole: {
    flex: 1,
    marginTop: 40,
    marginLeft: 0,
    justifyContent: 'top',
    backgroundColor: '#c1e7dd',
    width: 320,
    height: 800,
    padding: 8,
    borderRadius: 50,
  },

  containerAccount: {
    margin: 5,
    backgroundColor: 'white',
    flexDirection: 'row',
  },

  textAddMech: {
    fontFamily: 'yrsa',
    fontSize: 30,
    color: 'white',
    textAlign: 'center',
  },

  textAddMechForm: {
    margin: 5,
    marginLeft: 15,
    marginTop: 25,
    fontFamily: 'yrsa',
    fontSize: 20,
    color: 'white',
    textAlign: 'Left',
  },

  containerAddMecha: {
    margin: 5,
    borderWidth: 2,
    borderRadius: 10,
    backgroundColor: '#8c8e8d',
    width: '90%',
    height: 500,
  },

  buttonAdd: {
    margin: 5,
    marginLeft: 35,
    padding: 10,
    width: '80%',
    height: 45,
    borderWidth: 2,
    borderRadius: 15,
    borderColor: 'black',
    backgroundColor: '#DBE5E5',
    textAlign: 'center',
    fontWeight: 'bold',
  },

  buttonSave: {
    margin: 5,
    marginLeft: 90,
    padding: 10,
    width: '40%',
    height: 45,
    borderWidth: 2,
    borderRadius: 15,
    borderColor: 'black',
    backgroundColor: '#DBE5E5',
    textAlign: 'center',
    fontWeight: 'bold',
  },

  addmechaDrop: {
    height: 35,
    width: 250,
    margin: 5,
    marginEnd: 10,
    marginLeft: 10,
    marginBottom: 20,
    padding: 5,
    backgroundColor: 'white',
    borderColor: 'black',
    borderWidth: 2,
    borderRadius: 10,
  },

  inputAddMecha: {
    backgroundColor: 'white',
    margin: 15,
    marginLeft: 10,
    width: 150,
    height: 30,
    borderWidth: 2,
    borderRadius: 10,
    padding: 5,
  },

  inputAddMecha2: {
    backgroundColor: 'white',
    margin: 5,
    marginLeft: 10,
    width: 250,
    height: 30,
    borderWidth: 2,
    borderRadius: 10,
    padding: 5,
  },

  title: {
    margin: 15,
    padding: 10,
    textAlign: 'center',
    backgroundColor: '#ffa700'
  },

  paragraph: {
    textAlign: 'center',
    margin: 10,
    padding: 5,
    fontSize: 15,
    fontWeight: 'bold',
  },

  paragraphChr: {
    textAlign: 'center',
    margin: 10,
    padding: 5,
    fontSize: 25,
    fontWeight: 'bold',
  },

  loginView:{
    margin: 5,
    width: '100%'
  },

  inputV: {
    margin: 5,
    marginLeft: 30,
    flexDirection: "row",
  }, 


//role
  roleView: {
    marginTop: -50,
    marginLeft: 40,
    width: '75%',
    height: 250,
    backgroundColor: 'white',
    borderWidth: 2,
    borderRadius: 50,
    borderColor: '#9cc2b8',
    justifyContent: 'center',
  }, 

  role: {
    margin: 5,
    padding: 5,
    borderWidth: 2,
    flexDirection: 'row',
    textAlign: 'center',
  },

  roleText: {
    mergin: 20,
    fontSize: 15,
  },


//customer: choose vehicle
  custView: {
    margin: 5,
    flexDirection: 'row',
  },

  choose: {
    fontSize: 25,
    fontFamily: 'Times New Romans',
    textAlign: 'center',
  },

  buttonVehic: {
    margin: 5,
    marginLeft: 15,
    width: 130,
    height: 130,
    borderWidth: 2,
    borderColor: 'teal',
    borderRadius: 5,
    textAlign: 'center',
    justifyContent: 'center',
    backgroundColor: '#91C9CB',
  }, 

  imgVehicle: {
    margin: 10,
    marginLeft: 15,
    width: '70%',
    height: '60%',
  },

  

//input
  inputSty: {
    margin: 5,
    marginLeft: 25,
    marginUp: 25,
    padding: 5,
    width: '70%',
    height: 25,
    backgroundColor: 'white',
    borderColor: 'black',
    borderWidth: 2,
  },

  notifSty: {
    color: 'red',
    textAlign: 'center',
  },

  notifSty2: {
    color: 'green',
    textAlign: 'center',
  },

  archiveinputSty: {
    margin: 2,
    padding: 5,
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: 'black'
  },

//Form

  titleForm: {
    margin: 15,
    padding: 10,
    fontSize: 25,
    fontWeight: 'Bold',
    fontFamily: 'yrsa',
    color: 'white',
    textAlign: 'center',
  },

  unit: {
    height: 50,
    width: 300,
    marginEnd: 10,
    marginLeft: 15,
    marginBottom: 20,
    padding: 5,
    backgroundColor: '#DBE5E5',
    borderWidth: 2,
    borderRadius: 15,
  },

  textInputVehic: {
    margin: 15,
    padding: 5,
    paddingLeft: 15,
    width: '90%',
    height: 50,
    borderWidth: 2,
    borderRadius: 15,
    borderColor: 'teal',
    backgroundColor: 'white',
  },

  buttonUpdate: {
    margin: 5,
    marginLeft: 10,
    padding: 10,
    width: '40%',
    height: 45,
    borderWidth: 2,
    borderRadius: 15,
    borderColor: 'teal',
    backgroundColor: '#DBE5E5',
    textAlign: 'center',
    fontWeight: 'bold',
  },

  buttonVForm: {
    flexDirection: 'row',
    marginLeft: 20,
  },

  buttonUpload: {
    margin: 5,
    marginLeft: 15,
    width: '90%',
    height: 40,
    padding: 8,
    borderWidth: 2,
    borderRadius: 15,
    borderColor: 'teal',
    backgroundColor: '#DBE5E5',
  },

  textForm: {
    margin: 5,
    marginTop: 15,
    marginLeft: 25,
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'left',
  },

  iconForm: {
    margin: 0,
    marginLeft: 170,
    marginRight: 10,
    width: 20,
    height: 20,
  },

  textupload: {
    margin: 0,
    marginLeft: 12,
    color: 'black',
    fontSize: 13,
    textAlign: 'left',
  },

  uploadV: {
    margin: 0,
    marginLeft: 0,
    flexDirection: "row",
  }, 

//Mechanic: Home

  //Container Top
  containerTop: {
    margin: 0,
    borderBottomWidth: 1,
    borderColor: 'black',
    height: 50,
    backgroundColor: 'white' ,
    flexDirection: 'ROW',
    shadowOffset: 50,
    shadowColor:'black',
    shadowOpacity: 50,
  },

  containerTopUser: {
    margin: 0,
    height: 50,
    flexDirection: 'ROW',
    shadowOffset: 50,
    shadowColor:'black',
    shadowOpacity: 50,
  },

  searchbar: {
    margin: 5,
    padding: 20,
    borderRadius: 20,
    width: 200,
    height: 40,
    backgroundColor: 'white',
  }, 

  searchbarCont: {
    margin: 5,
    flexDirection: 'row',
    justifyContent: 'center',
  }, 

  walletCont: {
    margin: 5,
    padding: 10,
    borderRadius: 5,
    flexDirection: 'row',
    height: 90,
  },

  wallet: {
    margin: 5,
    marginLeft: 10,
    padding: 10,
    borderRadius: 25,
    flexDirection: 'row',
    backgroundColor: 'white',
    width: 170,
    height: 70,
    textAlign: 'center',
  },

  walletValue: {
    marginTop: 10,
    textAlign: 'center',
  },

  scanIcon: {
    margin: 5,
    marginTop: 10,
    width: 25,
    height: 25,
  },

  walletIcon: {
    margin: 5,
    marginLeft: 10,
    width: 25,
    height: 30,
  },

  clockIcon: {
    margin: 0,
    marginTop: 15,
    marginLeft: 5,
    width: 30,
    height: 30,
  },

  clockValue: {
    textAlign: 'center',
    width: 60,

  },

  containerBottomCust: {
    margin: 0,
    marginTop: 260,
    borderTopWidth: 1,
    borderColor: 'black',
    height: 70,
    backgroundColor: 'white' ,
    flexDirection: 'ROW',
    justifyContent: 'bottom',
  },

  orderStat: {
    margin: 5,
    marginLeft: 5,
    padding: 5,
    borderRadius: 25,
    flexDirection: 'row',
    backgroundColor: 'white',
    textAlign: 'center',
    width: 100,
    height: 70,
  },

  containerUserMenu: {
    margin: 15,
    width: '95%',
    flexDirection: 'row',
  },

  buttonuserMenu: {
    margin: 5,
    marginLeft: 20,
    width: 70,
    height: 70,
    borderWidth: 2,
    borderColor: 'teal',
    borderRadius: 5,
    textAlign: 'center',
    justifyContent: 'center',
    backgroundColor: '#91C9CB',
  },

  menuIconCar: {
    marginLeft: 3,
    width: 60,
    height: 25,
  },

  containerMechanicList: {
    backgroundColor: 'white',
    padding: 2,
    borderRadius: 5,
    height: 250,
  },

  menuIconBike: {
    marginLeft: 3,
    width: 60,
    height: 60,
  },

  menuIconGarage: {
    marginLeft: 3,
    width: 60,
    height: 60,
  },

  buttonSearch: {
    margin: 5,
    width: 40,
    height: 40,
    backgroundColor: 'white',
    textAlign: 'center',
    borderRadius: 30,
  },

  containerBottom: {
    margin: 0,
    marginTop: 150,
    borderTopWidth: 1,
    borderColor: 'black',
    height: 70,
    backgroundColor: 'white' ,
    flexDirection: 'ROW',
    justifyContent: 'bottom',
  },

  containerBottomHome: {
    margin: 0,
    marginTop: 260,
    borderTopWidth: 1,
    borderColor: 'black',
    height: 70,
    backgroundColor: 'white' ,
    flexDirection: 'ROW',
    justifyContent: 'bottom',
  },

  containerBottomOwner: {
    margin: 0,
    marginTop: 100,
    borderTopWidth: 1,
    borderColor: 'black',
    height: 70,
    backgroundColor: 'white' ,
    flexDirection: 'ROW',
    justifyContent: 'bottom',
  },

  containerBottomDetailOwner: {
    margin: 0,
    marginTop: 215,
    borderTopWidth: 1,
    borderColor: 'black',
    height: 70,
    backgroundColor: 'white' ,
    flexDirection: 'ROW',
    justifyContent: 'bottom',
  },

  containerDetail: {
    margin: 5,
    marginLeft: 10,
    padding: 10,
    borderRadius: 5,
    backgroundColor: 'white',
    width: '95%',
    height: 250,
  },

  containerIssueDetail: {
    margin: 5,
    padding: 10,
    borderRadius: 5,
    backgroundColor: 'white',
    width: '95%',
    height: 100,
  },

  containerImage: {
    marginLeft: 0,
    height: 100,
    flexDirection: 'row',
  }, 

  arrow: {
    marginTop: 50,
    width:10,
    height: 10,
  },

  buttonAccept: {
    margin: 5,
    marginLeft: 95,
    padding: 5,
    color: 'black',
    backgroundColor: '#D9D9D9',
    width: 150,
    height: 50,
    borderRadius: 10,
    borderWidth: 2,
    justifyContent: 'center',
    textAlign: 'center',
  },

//Map
  imageMap: {
    width: '100%',
    height: '50%',
  }, 

  pin: {
    marginTop: 3,
  },

  containerBottomMap: {
    margin: 0,
    marginTop: 20,
    borderTopWidth: 1,
    borderColor: 'black',
    height: 70,
    backgroundColor: 'white' ,
    flexDirection: 'ROW',
    justifyContent: 'bottom',
  },

  containerVehicDetail: {
    margin: 2,
    marginLeft: 10,
    padding: 10,
    borderRadius: 5,
    borderWidth: 1,
    backgroundColor: 'white',
    width: '95%',
    height: 100,
  },

  containerVehic: {
    padding: 0,
    justifyContent: 'row',
    borderBottomWidth: 1,
  },

  mechanicOngoing: {
    margin: 5,
    flexDirection: 'row',
  },  

  textTop: {
    marginTop: 10,
    marginLeft: 55,
    marginRight: 55,
    fontFamily: 'ysra',
    fontSize: 25,
    fontWeight: 'bold',
  },

  titleOrder: {
    margin: 5,
    padding: 10,
    fontSize: 20,
    fontWeight: 'Bold',
    fontFamily: 'yrsa',
    color: 'black',
    textAlign: 'left',
  },

  buttonMenuBottom: {
    marginLeft: 35,
    textAlign: 'center',
  },

  containerServices: {
    textAlign: 'center',
    justifyContent: 'center',
  },

  custChatName: {
    fontSize: 15,
  },

  custData: {
    fontSize: 10,
  },

  custDataV: {
    margin: 5,
    marginRight: 80,
  },

  containerHomeMenu: {
    margin: 0,
    borderBottomWidth: 2,
    borderColor: '#CFE2E2, #D0E8E900'
  },

  iconSmall: {
    margin: 5,
    marginLeft: 15,
    marginRight: 10,
    width: 40,
    height: 40,
  },

  iconDisplay: {
    margin: 5,
    marginLeft: 5,
    marginRight: 10,
    width: 40,
    height: 40,
  },

  containerList: {
    margin: 5,
    marginLeft: 10,
    padding: 10,
    borderRadius: 5,
    backgroundColor: 'white',
    width: '95%',
    height: 150,
    flexDirection: 'row',
  },

  buttonDetail: {
    margin: 5,
    marginTop: 110,
    padding: 5,
    color: 'blue',
    justifyContent: 'bottom',
    textAlign: 'bottom',
    fontSize: 12,
  },

  dataView: {
    margin: 5,
    marginTop: 0,
    padding: 5,

  },

  

  buttonSty: {
    margin: 5,
    padding: 5,
    color: 'black',
    backgroundColor: 'cyan',
    width: 150,
    height: 50,
    borderRadius: 10,
    justifyContent: 'center',
    textAlign: 'center',
  },

  buttonV: {
    marginLeft: 85,
    marginTop: 60,
  },

  buttonStyLogin: {
    margin: 5,
    padding: 5,
    color: 'black',
    backgroundColor: 'cyan',
    width: 150,
    height: 50,
    borderWidth: 2,
    borderRadius: 10,
    justifyContent: 'center',
    textAlign: 'center',
  },

  buttonLogin: {
    marginLeft: 70,
    marginTop: 30,
  },

  buttonRole: {
    margin: 5,
    marginTop: 5,
    padding: 5,
    fontSize: 20,
    borderWidth: 2,
    borderRadius: 10,
    flexDirection: 'row',
    textAlign: 'center',
    height: 40,
  },


  goSignup: {
    margin: 5,
    justifyContent: 'center',
    textAlign: 'center',
  },

  logoSty: {
    marginLeft: 50,
    marginTop: 10,
    marginBottom: 10,
    width: '70%',
    height: 120,
  },

  

  imageSty: {
    margin: 5,
    marginTop: 50,
    marginLeft: 35,
    width: 260,
    height: 230,
    borderColor: 'black',
    backgroundColor: 'black',
  },

  imageSty2: {
    margin: 5,
    marginTop: 30,
    marginBottom: 30,
    marginLeft: 85,
    width: 150,
    height: 150,
    borderColor: 'white',
    backgroundColor: 'white',
  },

  icon: {
    margin: 7,
    marginLeft: 7,
    width: 25,
    height: 25,
  },

  iconView: {
    margin: 20,
    marginLeft: 110,
    flexDirection: 'row'
  },

  iconPress: {
    width: 50,
    height: 50,
  },

})