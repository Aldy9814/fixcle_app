import React from 'react';
import {StyleSheet, Text, View, Image, TextInput, TouchableOpacity} from 'react-native';
import {globalsty} from './globalSty'
import {useState} from 'react';

export default function UserHome ({navigation}) {

  const [search, setSearch] = useState ('')

  const searching=(search)=>{setSearch(search)}

  const goChat=()=>{
    navigation.navigate('Chat')
  }

return(

  <View style={globalsty.containerDefault}>

  <View style={globalsty.containerTopUser}>
      <Image style={globalsty.iconSmall} source={require('./Image/LogoFixcle.png')}/>
      <Text style={globalsty.textTop}>FIXCLE</Text>
      <Image style={globalsty.iconSmall} source={require('./Icon/bell.png')} /> 
  </View>

  <View style={globalsty.searchbarCont}>
    <TextInput style={globalsty.searchbar} placeholder="Search" onChangeText={searching} />
    <TouchableOpacity style={globalsty.buttonSearch}>
      <Image style={globalsty.icon} source={require('./Icon/magni.jpg')} />
    </TouchableOpacity>
  </View>

  <View style={globalsty.walletCont}>

    <View style={globalsty.wallet}>

      <Image style={globalsty.scanIcon} source={require('./Icon/scan2.png')} />

      <Image style={globalsty.walletIcon} source={require('./Icon/wallet.png')} />

      <View style={globalsty.walletValue}>
        <Text> Rp200.000 </Text>
      </View>
    </View>

    <View style={globalsty.orderStat}>

      <Image style={globalsty.clockIcon} source={require('./Icon/clock.png')} />

      <View style={globalsty.clockValue}>
        <Text> Check Order Status </Text>
      </View>

    </View>


  </View>

  <View style={globalsty.containerUserMenu}>

  <View style={globalsty.containerServices}>
    <TouchableOpacity style={globalsty.buttonuserMenu}>  
      <Image style={globalsty.menuIconCar} source={require('./Icon/carWhite.png')} />
      
    </TouchableOpacity>

    <Text>     Car Service </Text>
    <Text>     </Text>
  </View>

  <View>
    <TouchableOpacity style={globalsty.buttonuserMenu}>  
      <Image style={globalsty.menuIconBike} source={require('./Icon/bikeWhite.png')} />

    </TouchableOpacity>
    <Text>      Motorbike</Text>
    <Text>         Service</Text>
  </View>

  <View>
    <TouchableOpacity style={globalsty.buttonuserMenu}>  
      <Image style={globalsty.menuIconGarage} source={require('./Icon/garage.png')} />

    </TouchableOpacity>
    <Text>      Workshop </Text>
    <Text>            List </Text>
  </View>

  </View>

  <View style={globalsty.containerBottomCust}>
      <TouchableOpacity style={globalsty.buttonMenuBottom}>
      <Image style={globalsty.iconSmall} source={require('./Icon/messege.png')}/>
      <Text>  chat </Text>
      </TouchableOpacity>

      <TouchableOpacity style={globalsty.buttonMenuBottom}>
      <Image style={globalsty.iconSmall} source={require('./Icon/home.png')} />
      <Text>  home </Text>
      </TouchableOpacity>

      <TouchableOpacity style={globalsty.buttonMenuBottom}>
      <Image style={globalsty.iconSmall} source={require('./Icon/profile.png')} /> 
      <Text>   account </Text>
      </TouchableOpacity>
  </View>

  </View>
)
}