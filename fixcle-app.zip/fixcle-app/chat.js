import React from 'react';
import {StyleSheet, Text, View, Image, TextInput, TouchableOpacity} from 'react-native';
import {globalsty} from './globalSty'
import {useState} from 'react';

export default function Chat ({navigation}) {
  return (

    <View> 
    
    </View>


  )
}