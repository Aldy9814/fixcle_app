import React from 'react';
import {StyleSheet, Text, View, Image, TextInput, TouchableOpacity} from 'react-native';
import {globalsty} from './globalSty'
import {useState} from 'react';

export default function Home ({navigation}) {

const goLogin =()=> {
  navigation.navigate('Login')
}

const goSignup =()=> {
  navigation.navigate('Signup')
}


return(

<View style={globalsty.containerHome}>

<Image style={globalsty.imageSty} source={require('./Image/LogoFixcle.png')}/>


<View style={globalsty.buttonV}>

<TouchableOpacity style={globalsty.buttonSty} onPress={goLogin}>
  <Text>Login</Text>
</TouchableOpacity>

<TouchableOpacity style={globalsty.buttonSty} onPress={goSignup}>
  <Text>Sign Up</Text>
</TouchableOpacity>

</View>



</View>


)


}