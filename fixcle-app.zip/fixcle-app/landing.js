import React from 'react';
import {StyleSheet, Text, View, Image, TextInput, TouchableOpacity} from 'react-native';
import {globalsty} from './globalSty'
import {useState} from 'react';

export default function Landing ({navigation}) {

  const customer=()=>{
    navigation.navigate("Customer")
  }

  const mechanic=()=>{
    navigation.navigate("Mechanic")
  }

  const owner=()=>{
    navigation.navigate("Owner")
  }

return(

<View style={globalsty.containerLogin}>

<Image style={globalsty.imageSty2} source={require("./Image/LogoFixcle.png")} />

<View style={globalsty.containerRole}> 

  <View style={globalsty.roleView}> 

    <TouchableOpacity style={globalsty.buttonRole} onPress={customer}> 
    <Image style={globalsty.icon} source={require("./Icon/customerIcon.png")}/>
    <Text style={globalsty.roleText}> Customer </Text>
    </TouchableOpacity>

    <TouchableOpacity style={globalsty.buttonRole} onPress={mechanic}> 
    <Image style={globalsty.icon} source={require("./Icon/mechanicIcon.png")}/>
    <Text style={globalsty.roleText}> Mechanic </Text>
    </TouchableOpacity>

    <TouchableOpacity style={globalsty.buttonRole} onPress={owner}> 
    <Image style={globalsty.icon} source={require("./Icon/ownerIcon.png")}/>
    <Text style={globalsty.roleText}> Owner </Text>
    </TouchableOpacity>

  </View>

</View>




</View>



)
}