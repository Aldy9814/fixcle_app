import {createStackNavigator} from 'react-navigation-stack';
import {createAppContainer} from 'react-navigation';

import Login from './login';
import Home from './home';
import Signup from './signup';
import Landing from './landing';

import Form from './form';

import Customer from './customer';
import Mobil from './mobil'
import Motor from './motor'
import UserHome from './userHome'

import Mechanic from './mechanic/mechanic';
import MechanicDetail from './mechanic/mechanicDetail';
import MechanicMap from './mechanic/mechanicMap';

import Owner from './owner'
import OwnerOfficial from './ownerFormOfficial'
import OwnerNon from './ownerFormNon'
import OwnerHome from './ownerHome'
import OwnerDetail from './ownerDetail'

import Chat from './chat'


const screens = {


  Home: {
    screen: Home,
  },

  OwnerNon: {
    screen: OwnerNon
  },

  OwnerDetail: {  
    screen: OwnerDetail
  },
  
  OwnerHome: {
    screen: OwnerHome
  },

  UserHome: {
    screen: UserHome
  },

  Login: {
    screen: Login
  },

  Signup: {
    screen: Signup
  },

  Landing: {
    screen: Landing
  },

  Form: {
    screen: Form
  },

  Customer: {
    screen: Customer
  },

  Mobil: {  
    screen: Mobil
  },

  Motor: {
    screen: Motor
  },

  Owner: {
    screen: Owner
  },

  OwnerOfficial: {
    screen: OwnerOfficial
  },

  Mechanic: {
    screen: Mechanic
  },

  MechanicMap: {
    screen: MechanicMap
  },

  MechanicDetail: {
    screen: MechanicDetail
  },

  Chat: {
    screen: Chat
  },
  
  

}
const HomeStack = createStackNavigator (screens);
export default createAppContainer (HomeStack);
