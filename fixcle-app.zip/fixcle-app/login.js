import React from 'react';
import {StyleSheet, Text, View, Image, TextInput, TouchableOpacity} from 'react-native';
import {globalsty} from './globalSty'
import {useState} from 'react';

export default function Login ({navigation}) {

const [user, setuser] = useState("")
const [pass, setpass] = useState("")

const inputUser =(user)=>{setuser(user)}
const inputPass =(pass)=>{setpass(pass)}

//const [userSave, setuserSave] = useState 

const [notif, setnotif] = useState("")

const signup=()=>{
  navigation.navigate('Signup')
}

const login=()=>{
if(user == 'user1' && pass == '123456'){
  navigation.navigate('Landing')
}
else{
  setnotif('Maaf username atau password anda salah!')
}
}

return(

<View style={globalsty.containerLogin}>

<Image style={globalsty.imageSty2} source={require("./Image/LogoFixcle.png")}/>

<View style={globalsty.containerLogin2}>

<View style={globalsty.inputV}>
  <TextInput style={globalsty.inputSty} placeholder="username" onChangeText={inputUser} />
</View>

<View style={globalsty.inputV}>
  <TextInput style={globalsty.inputSty} placeholder="password" onChangeText={inputPass} />
</View>

<View style={globalsty.buttonLogin}>
  <TouchableOpacity style={globalsty.buttonStyLogin} onPress={login}> LOGIN </TouchableOpacity>
</View>

<View>
  <Text style={globalsty.notifSty}> {notif} </Text>
</View>

<View style={globalsty.goSignup}>
  <Text> Already have an account? </Text>

  <TouchableOpacity onPress={signup}> Signup </TouchableOpacity>
</View>



</View>
</View>

)



}