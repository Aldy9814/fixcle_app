import React from 'react';
import {StyleSheet, Text, View, Image, TextInput, TouchableOpacity, Picker} from 'react-native';
import {globalsty} from './globalSty'
import {useState} from 'react';

export default function OwnerNon ({navigation}) {

  const [service, setService] = useState('')
  const [s, setS] = useState('')
  
  const [workshop, setWorkshop] = useState('')
  const [address, setAddress] = useState('')
  const [notif1, setNotif1] = useState('')
  const [notif2, setNotif2] = useState('')

  const inputWorkshop =(workshop)=>{setWorkshop(workshop)}
  const inputAddress =(address)=>{setAddress(address)}

  

  const update=()=>{
    if(workshop == ''){
      setNotif2('')
      setNotif1('please fill your info!')
    }
    else if(address == ''){
      setNotif2('')
      setNotif1('please fill your info!')
    }
    else if(service == ''){
      setNotif2('')
      setNotif1('please fill your info!')
    }
    else{
      setNotif1('')
      setNotif2('your info has been updated')
    }
  }

  const goHome=()=>{
    if(notif2 == 'your info has been updated'){
      navigation.navigate('OwnerHome')
    }
    else{
      setNotif1('Please Check Your Form!')
    }
  }
return(

  <View style={globalsty.containerForm}>

  <Text style={globalsty.titleForm}> Register </Text>

  <TextInput style={globalsty.textInputVehic} placeholder='Input Workshop Name' onChangeText={inputWorkshop} />

  <TextInput style={globalsty.textInputVehic} placeholder='Input Workshop Address' onChangeText={inputAddress} />

  <Text style={globalsty.textForm}>Available Services </Text>
  <Picker 
    style={globalsty.unit}
    selectedValue = {service}
    onValueChange={(s, itemIndex) => setService(s)}>
    <Picker.Item label = 'Choose Services' value = ''/>
    <Picker.Item label = 'Car' value = 'Car'/>
    <Picker.Item label = 'Motorcycle' value = 'Motorcycle'/>
    <Picker.Item label = 'Car & Motorcycle' value = 'CarMotorcycle'/>
  </Picker>


  <Text style={globalsty.notifSty}> {notif1} </Text>
  <Text style={globalsty.notifSty2}> {notif2} </Text>

  <View style={globalsty.buttonVForm}>
    <TouchableOpacity style={globalsty.buttonUpdate} onPress={update}> Update Info </TouchableOpacity>
    <TouchableOpacity style={globalsty.buttonUpdate} onPress={goHome}> Go to Home </TouchableOpacity>
  </View>

  </View>
)
}