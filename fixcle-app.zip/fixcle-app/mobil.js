import React from 'react';
import {StyleSheet, Text, View, Image, TextInput, TouchableOpacity, Picker} from 'react-native';
import {globalsty} from './globalSty'
import {useState} from 'react';

export default function Mobil ({navigation}) {

  const [b, setB] = useState('')
  const [y, setY] = useState('')
  const [f, setF] = useState('')
  const [plat, setPlat] = useState('')
  const [notif1, setNotif1] = useState('')
  const [notif2, setNotif2] = useState('')
  

  const inputPlat =(plat)=>{setPlat(plat)}

  const [brand,setBrand] = useState('')
  const [year, setYear] = useState('')
  const [fuel, setFuel] = useState('')

  const update=()=>{
    if(plat == ''){
      setNotif2('')
      setNotif1('please fill your info!')
    }
    else if(year == ''){
      setNotif2('')
      setNotif1('please fill your info!')
    }
    else if(brand == ''){
      setNotif2('')
      setNotif1('please fill your info!')
    }
    else if(fuel == ''){
      setNotif2('')
      setNotif1('please fill your info!')
    }
    else{
      setNotif1('')
      setNotif2('your info has been updated')
    }
  }

  const goHome=()=>{
    if(notif2 == 'your info has been updated'){
      navigation.navigate('UserHome')
      setNotif1('')
    }
    else{
      setNotif1('Please Check Your Form!')
    }
  }

return(

<View style={globalsty.containerForm}>

  <Text style={globalsty.titleForm}> CAR </Text>

  <TextInput style={globalsty.textInputVehic} placeholder='Input Plate Number' onChangeText={inputPlat} />

  <Text style={globalsty.textForm}>Year </Text>
  <Picker 
    style={globalsty.unit}
    selectedValue = {year}
    onValueChange={(y, itemIndex) => setYear(y)}>
    <Picker.Item label = 'Choose Year' value = ''/>
    <Picker.Item label = '2015' value = '2015'/>
    <Picker.Item label = '2016' value = '2016'/>
    <Picker.Item label = '2017' value = '2017'/>
    <Picker.Item label = '2018' value = '2018'/>
    <Picker.Item label = '2019' value = '2019'/>
    <Picker.Item label = '2020' value = '2020'/>
  </Picker>

  <Text style={globalsty.textForm}>Brand </Text>
  <Picker 
    style={globalsty.unit}
    selectedValue = {brand}
    onValueChange={(b, itemIndex) => setBrand(b)}>
    <Picker.Item label = 'Choose Brand' value = ''/>
    <Picker.Item label = 'Audi' value = 'Audi'/>
    <Picker.Item label = 'Chevrolet' value = 'Chevrolet'/>
    <Picker.Item label = 'Daihatsu' value = 'Daihatsu'/>
    <Picker.Item label = 'Honda' value = 'Honda'/>
    <Picker.Item label = 'Nissan' value = 'Nissan'/>
    <Picker.Item label = 'Toyota' value = 'Toyota'/>
  </Picker>

  <Text style={globalsty.textForm}>Fuel </Text>
  <Picker 
    style={globalsty.unit}
    selectedValue = {fuel}
    onValueChange={(f, itemIndex) => setFuel(f)}>
    <Picker.Item label = 'Choose Fuel' value = ''/>
    <Picker.Item label = 'Pertamax' value = 'Pertamax'/>
    <Picker.Item label = 'Pertalite' value = 'Pertalite'/>
    <Picker.Item label = 'Solar' value = 'Solar'/>
  
  </Picker>

  <Text style={globalsty.notifSty}> {notif1} </Text>
  <Text style={globalsty.notifSty2}> {notif2} </Text>
  
  <View style={globalsty.buttonVForm}>
    <TouchableOpacity style={globalsty.buttonUpdate} onPress={update}> Update Info </TouchableOpacity>
    <TouchableOpacity style={globalsty.buttonUpdate} onPress={goHome}> Go to Home </TouchableOpacity>
  </View>

</View>

)


}
